import { Link } from 'react-router-dom';

const BookingConfirmationPage = () => {
  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-8 col-lg-6 col-xl-5">
          <div className="card shadow-lg border-0 rounded-lg p-5 bg-gradient-to-r from-teal-500 via-blue-500 to-indigo-600 text-center fadeInCard">
            <h1 className="text-white text-4xl font-bold mb-4 animate__animated animate__fadeIn">
            <marquee direction="right"
                 >Booking Confirmed!</marquee></h1>
            <p className="text-white text-lg mb-6 animate__animated animate__fadeIn animate__delay-1s">
              Thank you for booking with us. We look forward to your stay.
            </p>
            <Link to="/" className="btn btn-light btn-lg shadow-lg transform transition duration-300 hover:scale-105 animate__animated animate__fadeIn animate__delay-2s">
              Go to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingConfirmationPage;
