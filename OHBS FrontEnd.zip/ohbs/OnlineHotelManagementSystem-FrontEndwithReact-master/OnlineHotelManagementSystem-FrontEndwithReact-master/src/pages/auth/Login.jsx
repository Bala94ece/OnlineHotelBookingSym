import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "axios";
import { motion } from "framer-motion";
import "bootstrap/dist/css/bootstrap.min.css";

const Login = () => {
  const [formData, setFormData] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const validate = () => {
    const errors = {};
    if (!formData.email.trim()) {
      errors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = "Email is invalid";
    }

    if (!formData.password.trim()) {
      errors.password = "Password is required";
    } else if (formData.password.length < 6) {
      errors.password = "Password must be at least 6 characters";
    }

    setErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const login = async (email, password) => {
    try {
      const response = await axios.post(
        "http://localhost:8080/users/login",
        { email, password },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      return response.data;
    } catch (error) {
      console.error("Login error:", error);
      return { success: false, role: null, userId: null };
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) {
      return;
    }

    setLoading(true);
    const { email, password } = formData;
    const result = await login(email, password);

    const { success, role, userId } = result;

    if (!success) {
      setErrors({ form: "Invalid credentials. Please try again." });
    } else {
      localStorage.setItem("userId", userId);
      localStorage.setItem("userRole", role);
      switch (role) {
        case "ADMIN":
          navigate("/bookings/all");
          break;
        case "HOTELMANAGER":
          navigate("/bookings/all");
          break;
        case "CUSTOMER":
          navigate("/");
          break;
        default:
          setErrors({ form: "Role not recognized." });
      }
    }
    setLoading(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -50 }}
      transition={{ duration: 0.8 }}
      className="d-flex align-items-center justify-content-center vh-100"
      style={{
        background: "linear-gradient(to top, #ff0000, #ffff00)",

        // background: "linear-gradient(160deg, #ff0000, #ffff00)", // Red to Yellow gradient
        backgroundSize: "200% 200%",
        animation: "gradientBG 10s ease infinite",
      }}
    >
      <div className="card shadow-lg rounded-lg border-0" style={{ maxWidth: "500px" }}>
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
          className="p-14"
        >
          <h1
            className="text-center fw-bold mb-4 animate__animated animate__bounceIn"
            style={{ color: "#ff6347" }} // Red color for the header to match gradient
          >
            ADMIN ~ MANAGER ~ CUSTOMER
          </h1>
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label htmlFor="email" className="form-label">
                Email Address
              </label>
              <input
                type="email"
                className={`form-control ${errors.email ? "is-invalid" : ""}`}
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
              {errors.email && <div className="invalid-feedback">{errors.email}</div>}
            </div>
            <div className="mb-3">
              <label htmlFor="password" className="form-label">
                Password
              </label>
              <input
                type="password"
                className={`form-control ${errors.password ? "is-invalid" : ""}`}
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
              />
              {errors.password && <div className="invalid-feedback">{errors.password}</div>}
            </div>
            {errors.form && <div className="alert alert-danger">{errors.form}</div>}
            <motion.button
              type="submit"
              className="btn w-100"
              disabled={loading}
              style={{
                background: "linear-gradient(90deg, #ff5f6d 0%, #ffc371 100%)", // Red to Yellow button gradient
                border: "none",
                color: "#fff",
                padding: "12px",
                fontWeight: "bold",
                borderRadius: "8px",
                transition: "0.3s",
              }}
              whileHover={{
                scale: 1.1,
                boxShadow: "0px 4px 12px rgba(0, 0, 0, 0.2)",
              }}
              whileTap={{
                scale: 0.98,
                boxShadow: "0px 4px 8px rgba(0, 0, 0, 0.1)",
              }}
            >
              {loading ? "Signing In..." : "Sign In"}
            </motion.button>
          </form>
          <p className="text-center mt-4">
            Don't have an account?{" "}
            <Link to="/signup" className="text-primary">
              Sign up here
            </Link>
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Login;
