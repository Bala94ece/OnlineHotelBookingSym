import React, { useState, useEffect } from "react";
import axios from "axios";
import { motion } from "framer-motion";

function AllBookings() {
  const [bookings, setBookings] = useState([]);
  const [page, setPage] = useState(0); // Current page
  const [rowsPerPage, setRowsPerPage] = useState(5); // Default to 5 rows per page

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await axios.get("http://localhost:8080/bookings/getAll");
        setBookings(response.data);
      } catch (error) {
        console.error("Error fetching bookings:", error);
      }
    };

    fetchBookings();
  }, []); // Run only once on mount

  // Pagination logic
  const handleChangePage = (newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0); // Reset to the first page when rows per page changes
  };

  const paginatedBookings = bookings.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  return (
    <motion.div
      className="container mx-auto px-4 py-6"
      style={{
        background: "linear-gradient(to bottom, #ff512f, #f09819)", // Red to yellow gradient
        minHeight: "100vh",
      }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 1 }}
    >
      <motion.h1
        className="text-4xl font-bold mb-6 text-center text-white"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        All Bookings
      </motion.h1>
      {bookings.length === 0 ? (
        <motion.div
          className="text-center text-gray-200 mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          No bookings available.
        </motion.div>
      ) : (
        <>
          <motion.div
            className="overflow-x-auto"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
          >
            <table className="min-w-full bg-white border rounded-lg overflow-hidden shadow-lg">
              <thead className="bg-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Room ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Check-In Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Check-Out Date
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {paginatedBookings.map((booking) => (
                  <tr key={booking.id}>
                    <td className="px-6 py-4 whitespace-nowrap">{booking.userId}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{booking.roomId}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{booking.checkInDate}</td>
                    <td className="px-6 py-4 whitespace-nowrap">{booking.checkOutDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </motion.div>

          {/* Pagination Controls */}
          <motion.div
            className="flex items-center justify-between mt-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex items-center">
              <motion.button
                onClick={() => handleChangePage(page - 1)}
                disabled={page === 0}
                className="px-4 py-2 bg-blue-500 text-white rounded-l-md hover:bg-blue-700 disabled:opacity-50 transition duration-300"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Previous
              </motion.button>
              <span className="px-4 py-2 bg-gray-200 text-gray-600">
                Page {page + 1} of {Math.ceil(bookings.length / rowsPerPage)}
              </span>
              <motion.button
                onClick={() => handleChangePage(page + 1)}
                disabled={page >= Math.ceil(bookings.length / rowsPerPage) - 1}
                className="px-4 py-2 bg-blue-500 text-white rounded-r-md hover:bg-blue-700 disabled:opacity-50 transition duration-300"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Next
              </motion.button>
            </div>
            <motion.select
              value={rowsPerPage}
              onChange={handleChangeRowsPerPage}
              className="border border-gray-300 px-4 py-2 rounded-md bg-white"
              whileHover={{ scale: 1.05 }}
            >
              <option value={5}>5 rows</option>
              <option value={10}>10 rows</option>
              <option value={25}>25 rows</option>
              <option value={50}>50 rows</option>
            </motion.select>
          </motion.div>
        </>
      )}
    </motion.div>
  );
}

export default AllBookings;
