import React, { useState, useEffect } from 'react';
import { PencilAltIcon, TrashIcon } from '@heroicons/react/solid';
import EditHotel from './EditHotel'; 
import { useNavigate } from 'react-router-dom'; 
import { ToastContainer, toast } from 'react-toastify'; 
import 'react-toastify/dist/ReactToastify.css'; 
import axios from 'axios';

function AllHotels() {
  const navigate = useNavigate(); 
  const [hotels, setHotels] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteConfirmation, setDeleteConfirmation] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editHotelData, setEditHotelData] = useState(null);
  const [addRoomConfirmation, setAddRoomConfirmation] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);

  useEffect(() => {
    axios.get('http://localhost:8080/hotels/getAll')
      .then((response) => {
        setHotels(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        setLoading(false);
      });
  }, []);

  const handleEdit = (hotelId) => {
    const hotelToEdit = hotels.find((hotel) => hotel.id === hotelId);
    setEditHotelData(hotelToEdit); 
  };

  const confirmDelete = (hotelId) => {
    setDeleteConfirmation(hotelId);
  };

  const cancelDelete = () => {
    setDeleteConfirmation(null);
  };

  const handleDelete = (hotelId) => {
    axios.delete(`http://localhost:8080/hotels/${hotelId}`)
      .then(() => {
        setHotels(hotels.filter((hotel) => hotel.id !== hotelId));
        setDeleteConfirmation(null); 
        toast.success('Hotel deleted successfully!', { position: 'top-right' });
      })
      .catch((error) => {
        toast.error(`Error deleting hotel: ${error.message}`, { position: 'top-right' });
      });
  };

  const handleSave = (updatedHotel) => {
    setHotels(hotels.map((hotel) => (hotel.id === updatedHotel.id ? updatedHotel : hotel)));
    setEditHotelData(null);
  };

  const showAddRoomConfirmation = (hotelId) => {
    setAddRoomConfirmation(hotelId); 
  };

  const cancelAddRoom = () => {
    setAddRoomConfirmation(null); 
  };

  const filteredHotels = hotels.filter(
    (hotel) => hotel.address && hotel.address.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleChangePage = (newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0); 
  };

  const paginatedHotels = filteredHotels.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-4xl font-bold mb-6 text-center text-gradient">All Hotels</h1>
      
      <div className="mb-4">
        <input
          type="text"
          placeholder="Search by Address..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="block w-full px-4 py-2 border-2 border-indigo-500 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-indigo-600 transition-all"
        />
      </div>

      {loading ? (
        <p className="text-center text-gray-500">Loading...</p>
      ) : error ? (
        <p className="text-center text-red-500">Error: {error}</p>
      ) : (
        <div className="overflow-x-auto border-2 border-gray-300 rounded-lg shadow-xl transition-all hover:shadow-2xl">
          {filteredHotels.length === 0 ? (
            <p className="p-4 text-center text-gray-500">No hotels found.</p>
          ) : (
            <>
              <table className="min-w-full divide-y divide-gray-200 transition-all hover:bg-gray-100">
                <thead className="bg-gradient-to-r from-indigo-600 to-indigo-400 text-white">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-medium text-gray-50 uppercase tracking-wider">ID</th>
                    <th className="px-6 py-3 text-left text-sm font-medium text-gray-50 uppercase tracking-wider">Name</th>
                    <th className="px-6 py-3 text-left text-sm font-medium text-gray-50 uppercase tracking-wider">Address</th>
                    <th className="px-6 py-3 text-left text-sm font-medium text-gray-50 uppercase tracking-wider">Description</th>
                    <th className="px-6 py-3 text-left text-sm font-medium text-gray-50 uppercase tracking-wider">Star Rating</th>
                    <th className="px-6 py-3 text-left text-sm font-medium text-gray-50 uppercase tracking-wider">Amenities</th>
                    <th className="px-6 py-3 text-left text-sm font-medium text-gray-50 uppercase tracking-wider">Contact</th>
                    <th className="px-6 py-3 text-left text-sm font-medium text-gray-50 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {paginatedHotels.map((hotel) => (
                    <tr key={hotel.id} className="transition-all hover:bg-indigo-100">
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{hotel.id}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{hotel.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{hotel.address}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-xs" style={{ maxWidth: '150px' }}>{hotel.description}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-xs" style={{ maxWidth: '100px' }}>{hotel.starRating}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-xs" style={{ maxWidth: '150px' }}>{hotel.amenities}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{hotel.contact}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button
                          onClick={() => handleEdit(hotel.id)}
                          className="text-indigo-600 hover:text-indigo-900 focus:outline-none transition-all mr-2"
                        >
                          <PencilAltIcon className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => confirmDelete(hotel.id)}
                          className="text-red-600 hover:text-red-900 focus:outline-none transition-all"
                        >
                          <TrashIcon className="h-5 w-5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="flex items-center justify-between mt-4">
                <button
                  onClick={() => handleChangePage(page - 1)}
                  disabled={page === 0}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all disabled:opacity-50"
                >
                  Previous
                </button>
                <span className="px-4 py-2 bg-indigo-100 text-indigo-600 rounded-lg">
                  Page {page + 1} of {Math.ceil(filteredHotels.length / rowsPerPage)}
                </span>
                <button
                  onClick={() => handleChangePage(page + 1)}
                  disabled={page + 1 === Math.ceil(filteredHotels.length / rowsPerPage)}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all disabled:opacity-50"
                >
                  Next
                </button>
              </div>
            </>
          )}
        </div>
      )}

      {editHotelData && (
        <EditHotel hotel={editHotelData} onSave={handleSave} onCancel={() => setEditHotelData(null)} />
      )}

      <ToastContainer />
    </div>
  );
}

export default AllHotels;
