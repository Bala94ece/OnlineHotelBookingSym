import { useState } from 'react';
import axios from 'axios';
import { motion } from 'framer-motion';

function AddHotel() {
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [contact, setContact] = useState('');
  const [description, setDescription] = useState('');
  const [amenities, setAmenities] = useState('');
  const [starRating, setStarRating] = useState('');
  const [images, setImages] = useState('');
  const [isPopupVisible, setIsPopupVisible] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newHotel = {
      name,
      address,
      contact,
      description,
      amenities,
      starRating,
      images: images.split(',').map((url) => url.trim())
    };

    try {
      const response = await axios.post('http://localhost:8080/hotels/create', newHotel, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      console.log('New Hotel:', response.data);
      setIsPopupVisible(true);
      setName('');
      setAddress('');
      setContact('');
      setDescription('');
      setAmenities('');
      setStarRating('');
      setImages('');
    } catch (error) {
      console.error('Error adding hotel:', error);
    }
  };

  return (
    <div
      className="container mx-auto px-4 py-6"
      style={{
        background: 'linear-gradient(to bottom, #a8c0ff, #3f88c5, #4e7ea8)',  // Soft pastel gradient
        borderRadius: '20px',
        boxShadow: '0 4px 15px rgba(0, 0, 0, 0.3)',
      }}
    >
      <h1 className="text-4xl font-bold mb-6 text-center text-gradient">Add New Hotel</h1>
      <form onSubmit={handleSubmit}>
        {/* Hotel Name */}
        <div className="mb-6">
          <label htmlFor="name" className="block text-2xl font-medium text-white mb-2">Hotel Name</label>
          <motion.input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="block w-full px-4 py-3 border-2 border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm transition-all ease-in-out"
            required
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          />
        </div>

        {/* Hotel Address */}
        <div className="mb-6">
          <label htmlFor="address" className="block text-2xl font-medium text-white mb-2">Hotel Address</label>
          <motion.input
            id="address"
            type="text"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="block w-full px-4 py-3 border-2 border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm transition-all ease-in-out"
            required
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          />
        </div>

        {/* Phone Number */}
        <div className="mb-6">
          <label htmlFor="contact" className="block text-2xl font-medium text-white mb-2">Phone Number</label>
          <motion.input
            id="contact"
            type="text"
            value={contact}
            onChange={(e) => setContact(e.target.value)}
            className="block w-full px-4 py-3 border-2 border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm transition-all ease-in-out"
            required
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          />
        </div>

        {/* Description */}
        <div className="mb-6">
          <label htmlFor="description" className="block text-2xl font-medium text-white mb-2">Description</label>
          <motion.textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="block w-full px-4 py-3 border-2 border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm transition-all ease-in-out"
            required
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          />
        </div>

        {/* Amenities */}
        <div className="mb-6">
          <label htmlFor="amenities" className="block text-2xl font-medium text-white mb-2">Amenities (comma separated)</label>
          <motion.textarea
            id="amenities"
            value={amenities}
            onChange={(e) => setAmenities(e.target.value)}
            className="block w-full px-4 py-3 border-2 border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm transition-all ease-in-out"
            required
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          />
        </div>

        {/* Star Rating */}
        <div className="mb-6">
          <label htmlFor="starRating" className="block text-2xl font-medium text-white mb-2">Star Rating</label>
          <motion.input
            id="starRating"
            type="number"
            value={starRating}
            onChange={(e) => setStarRating(e.target.value)}
            className="block w-full px-4 py-3 border-2 border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm transition-all ease-in-out"
            required
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          />
        </div>

        {/* Image URLs */}
        <div className="mb-6">
          <label htmlFor="images" className="block text-2xl font-medium text-white mb-2">Hotel Image URLs (comma separated)</label>
          <motion.textarea
            id="images"
            value={images}
            onChange={(e) => setImages(e.target.value)}
            className="block w-full px-4 py-3 border-2 border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm transition-all ease-in-out"
            required
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          />
        </div>

        {/* Submit Button */}
        <motion.button
          type="submit"
          className="w-full py-3 bg-indigo-500 hover:bg-indigo-600 text-white font-bold rounded-md transition-all transform hover:scale-105 ease-in-out"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Add Hotel
        </motion.button>
      </form>

      {/* Success Popup */}
      {isPopupVisible && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center animate-fadeIn">
          <div className="bg-white p-6 rounded shadow-md transition-all transform scale-95 hover:scale-100">
            <p className="text-lg font-medium text-indigo-600">Hotel created successfully!</p>
            <motion.button
              onClick={() => setIsPopupVisible(false)}
              className="mt-4 bg-indigo-500 hover:bg-indigo-600 text-white py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ease-in-out"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Close
            </motion.button>
          </div>
        </div>
      )}
    </div>
  );
}

export default AddHotel;
