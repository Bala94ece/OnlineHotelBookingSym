import React, { useState, useEffect } from "react";
import axios from "axios";

function AllBookings() {
  const [bookings, setBookings] = useState([]);
  const [page, setPage] = useState(0); // Current page
  const [rowsPerPage, setRowsPerPage] = useState(5); // Default to 5 rows per page

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await axios.get("http://localhost:8080/bookings/getAll");
        setBookings(response.data);
      } catch (error) {
        console.error("Error fetching bookings:", error);
      }
    };

    fetchBookings();
  }, []); // Empty dependency array ensures useEffect runs only once on component mount

  const handleChangePage = (newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0); // Reset to the first page when rows per page changes
  };

  const paginatedBookings = bookings.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  return (
    <div
      className="min-h-screen flex flex-col justify-center items-center px-4 py-6"
      style={{
        background: "linear-gradient(135deg, #1f4037 0%, #99f2c8 100%)",
        animation: "gradient-animation 10s ease infinite",
      }}
    >
      <style>
        {`
        @keyframes gradient-animation {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}
      </style>
      <div className="w-full max-w-6xl bg-white shadow-2xl rounded-lg p-6 transform hover:scale-105 transition-transform duration-500">
        <h1
          className="text-4xl font-extrabold text-center mb-6 animate-bounce"
          style={{
            color: "#2c786c",
          }}
        >
        <marquee direction="right">  ALL BOOKING LIST </marquee>
        </h1>
        {bookings.length === 0 ? (
          <div className="text-center text-gray-600 mt-8 animate-pulse">
            No bookings available.
          </div>
        ) : (
          <>
            <div className="overflow-x-auto rounded-lg border border-gray-300 shadow-lg">
              <table className="min-w-full bg-white text-sm">
                <thead className="bg-gradient-to-r from-green-500 via-teal-500 to-blue-500 text-white">
                  <tr>
                    <th className="px-6 py-3 text-left font-bold">USER ID</th>
                    <th className="px-6 py-3 text-left font-bold">ROOM ID</th>
                    <th className="px-6 py-3 text-left font-bold">
                      CHECK-IN DATE
                    </th>
                    <th className="px-6 py-3 text-left font-bold">
                    CHECK-OUT DATE
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {paginatedBookings.map((booking) => (
                    <tr
                      key={booking.id}
                      className="hover:bg-green-100 transition-colors duration-300"
                    >
                      <td className="px-6 py-4 whitespace-nowrap">
                        {booking.userId}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {booking.roomId}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {booking.checkInDate}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {booking.checkOutDate}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination controls */}
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center">
                <button
                  onClick={() => handleChangePage(page - 1)}
                  disabled={page === 0}
                  className="px-4 py-2 bg-gradient-to-r from-gray-300 to-gray-500 text-gray-800 rounded-l-md hover:from-gray-400 hover:to-gray-600 transition-all duration-300 disabled:opacity-50"
                >
                  Previous
                </button>
                <span className="px-4 py-2 bg-gray-200 text-gray-600">
                  Page {page + 1} of{" "}
                  {Math.ceil(bookings.length / rowsPerPage)}
                </span>
                <button
                  onClick={() => handleChangePage(page + 1)}
                  disabled={page >= Math.ceil(bookings.length / rowsPerPage) - 1}
                  className="px-4 py-2 bg-gradient-to-r from-gray-300 to-gray-500 text-gray-800 rounded-r-md hover:from-gray-400 hover:to-gray-600 transition-all duration-300 disabled:opacity-50"
                >
                  Next
                </button>
              </div>
              <select
                value={rowsPerPage}
                onChange={handleChangeRowsPerPage}
                className="border border-gray-300 px-4 py-2 rounded-md bg-white hover:shadow-lg transition-shadow duration-300"
              >
                <option value={5}>5 rows</option>
                <option value={10}>10 rows</option>
                <option value={25}>25 rows</option>
                <option value={50}>50 rows</option>
              </select>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default AllBookings;
