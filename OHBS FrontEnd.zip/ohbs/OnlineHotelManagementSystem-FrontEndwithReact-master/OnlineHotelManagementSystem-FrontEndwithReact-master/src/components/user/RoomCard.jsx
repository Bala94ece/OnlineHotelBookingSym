import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';

const RoomCard = ({ room }) => {
  const [isVisible, setIsVisible] = useState(false);

  // Fade-in effect when the card enters the viewport
  useEffect(() => {
    const timeout = setTimeout(() => {
      setIsVisible(true);
    }, 100); // Adds a delay for smooth transition

    return () => clearTimeout(timeout); // Cleanup on unmount
  }, []);

  return (
    <div
      className={`bg-white shadow-md rounded-lg overflow-hidden transition-transform transform hover:scale-105 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}
    >
      {/* Marquee for Special Offers */}
      <div className="bg-yellow-300 text-black py-2 mb-4">
        <marquee className="text-lg font-semibold">
          🏨 Special Offer! Book now and save 15% on this room! 🏨
        </marquee>
      </div>

      {/* Room Image */}
      {room.images && room.images.length > 0 ? (
        <img src={room.images[0]} alt={room.type} className="w-full h-48 object-cover" />
      ) : (
        <img src={room.images[0]}  />
      )}

      {/* Room Details */}
      <div className="p-4">
        <h2 className="text-xl font-bold mb-2 hover:text-blue-600 transition duration-300">{room.type} Room</h2>
        <p className="text-gray-700 mb-2">Hotel ID: {room.hotelId}</p>
        <p className="text-gray-700 mb-2">Available: {room.numberAvailable}</p>
        <p className="text-gray-800 font-bold mb-2">${room.pricePerNight} / night</p>

        {/* Book Now Button */}
        <Link
          to={`/rooms/${room.id}`}
          className="bg-blue-500 text-white px-4 py-2 rounded-lg transform transition duration-300 hover:bg-blue-600 hover:scale-105"
        >
          Book Now
        </Link>
      </div>
    </div>
  );
};

export default RoomCard;
