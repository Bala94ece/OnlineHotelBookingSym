const Footer = () => {
  return (
    <footer className="bg-gradient-to-r from-teal-500 to-blue-600 text-white py-8 mt-10">
      <div className="container mx-auto flex flex-wrap justify-between items-center">
        {/* HotelBooking Section */}
        <div className="w-full md:w-1/2 lg:w-1/4 mb-4 lg:mb-0">
          <h3 className="text-2xl font-extrabold mb-4 hover:text-teal-300 transition duration-300">HotelBooking</h3>
          <p className="text-sm mb-4">World's Luxurious Hotels</p>
          <div className="mt-4">
            <a href="#" className="text-blue-400 hover:text-blue-600 mr-4 transition duration-300">Facebook</a>
            <a href="#" className="text-blue-400 hover:text-blue-600 mr-4 transition duration-300">Twitter</a>
            <a href="#" className="text-blue-400 hover:text-blue-600 transition duration-300">Instagram</a>
          </div>
        </div>

        {/* Quick Links Section */}
        <div className="w-full md:w-1/2 lg:w-1/4 mb-4 lg:mb-0">
          <h3 className="text-2xl font-extrabold mb-4 hover:text-teal-300 transition duration-300">Quick Links</h3>
          <ul className="text-sm">
            <li><a href="#" className="text-gray-200 hover:text-white transition duration-300">Home</a></li>
            <li><a href="#" className="text-gray-200 hover:text-white transition duration-300">Hotels</a></li>
            <li><a href="#" className="text-gray-200 hover:text-white transition duration-300">Booking</a></li>
            <li><a href="#" className="text-gray-200 hover:text-white transition duration-300">Contact</a></li>
          </ul>
        </div>

        {/* Contact Us Section */}
        <div className="w-full md:w-1/2 lg:w-1/4 mb-4 lg:mb-0">
          <h3 className="text-2xl font-extrabold mb-4 hover:text-teal-300 transition duration-300">Contact Us</h3>
          <p className="text-sm mb-2">123 Hotel Street, City, Country</p>
          <p className="text-sm mb-2">Email: info@hotelbooking.com</p>
          <p className="text-sm">Phone: +123 456 7890</p>
        </div>

        {/* Newsletter Section */}
        <div className="w-full md:w-1/2 lg:w-1/4 mb-4 lg:mb-0">
          <h3 className="text-2xl font-extrabold mb-4 hover:text-teal-300 transition duration-300">Newsletter</h3>
          <p className="text-sm mb-4">Subscribe to our newsletter for exclusive offers and updates.</p>
          <form className="flex">
            <input
              type="email"
              placeholder="Your email"
              className="bg-gray-700 text-white px-4 py-2 rounded-l-md focus:outline-none"
            />
            <button
              type="submit"
              className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-r-md transition duration-300"
            >
              Subscribe
            </button>
          </form>
        </div>
      </div>

      {/* Footer Bottom Section */}
      <div className="mt-8 border-t border-gray-700 pt-4">
        <p className="text-center text-sm">&copy; 2024 HotelBooking. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;