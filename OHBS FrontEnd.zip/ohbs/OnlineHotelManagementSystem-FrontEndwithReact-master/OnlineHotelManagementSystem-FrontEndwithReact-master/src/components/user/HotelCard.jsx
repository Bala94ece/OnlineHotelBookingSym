import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';

const HotelCard = ({ hotel }) => {
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = useState(false);

  // Fade-in effect for the card when it enters the viewport
  useEffect(() => {
    const timeout = setTimeout(() => {
      setIsVisible(true);
    }, 100); // Adds a delay for smooth transition

    return () => clearTimeout(timeout); // Cleanup on unmount
  }, []);

  const handleViewMoreDetails = () => {
    navigate(`/hotels/${hotel.id}/rooms`);
  };

  return (
    <div
      className={`border p-4 rounded-lg shadow-lg transform transition-all duration-500 ease-in-out ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
    >
      {/* Marquee for Special Offers */}
      <div className="bg-yellow-300 text-black py-2 mb-4">
        <marquee className="text-lg font-semibold">
          🏨 Special Offer! Book now and save 20%! 🏨
        </marquee>
      </div>

      {/* Hotel Info */}
      <h2 className="text-2xl font-semibold mb-2 hover:text-blue-600 transition duration-300">{hotel.name}</h2>
      <p className="text-gray-700">Location: {hotel.address}</p>
      
      {hotel.images && hotel.images.length > 0 && (
        <img
          src={hotel.images[0]}
          alt="Hotel"
          className="w-full h-48 object-cover mt-2 rounded-lg transition-all duration-300 transform hover:scale-105"
        />
      )}

      {/* View More Details Button */}
      <button
        onClick={handleViewMoreDetails}
        className="mt-4 bg-blue-500 text-white py-2 px-4 rounded-lg transform transition duration-300 hover:bg-blue-600 hover:scale-105"
      >
        View More Details
      </button>
    </div>
  );
};

HotelCard.propTypes = {
  hotel: PropTypes.shape({
    id: PropTypes.number.isRequired,
    name: PropTypes.string.isRequired,
    address: PropTypes.string.isRequired,
    images: PropTypes.arrayOf(PropTypes.string),
  }).isRequired,
};

export default HotelCard;
