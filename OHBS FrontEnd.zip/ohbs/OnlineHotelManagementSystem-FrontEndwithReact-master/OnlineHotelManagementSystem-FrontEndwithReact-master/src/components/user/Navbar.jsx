import { Link } from 'react-router-dom';

const Navbar = ({ isLoggedIn }) => {
  return (
    <nav className="bg-gradient-to-r from-teal-500 to-blue-600 text-white p-4 shadow-md">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-3xl font-extrabold tracking-wider text-white hover:text-teal-300 transition duration-300">
          Hotel Booking
        </Link>
        <div>
          {isLoggedIn ? (
            <>
              <Link to="/" className="mx-3 text-lg font-medium hover:text-teal-300 transition duration-300">Home</Link>
              <Link to="/hotels" className="mx-3 text-lg font-medium hover:text-teal-300 transition duration-300">Hotels</Link>
              <Link to="/logout" className="mx-3 text-lg font-medium hover:text-teal-300 transition duration-300">Logout</Link>
            </>
          ) : (
            <>
              <Link to="/" className="mx-3 text-lg font-medium hover:text-teal-300 transition duration-300">Home</Link>
              <Link to="/logout" className="mx-3 text-lg font-medium hover:text-teal-300 transition duration-300">Logout</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
