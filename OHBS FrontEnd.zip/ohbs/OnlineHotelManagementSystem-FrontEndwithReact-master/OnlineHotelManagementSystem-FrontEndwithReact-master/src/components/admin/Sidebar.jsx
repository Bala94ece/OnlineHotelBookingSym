import React, { useState } from "react";
import { Link } from "react-router-dom";
import PropTypes from "prop-types";
import { motion } from "framer-motion";
import {
  CalendarIcon,
  DocumentTextIcon,
  OfficeBuildingIcon,
  UserIcon,
} from "@heroicons/react/outline";

const Sidebar = ({ isOpen }) => {
  const [bookingOpen, setBookingOpen] = useState(false);
  const [roomsOpen, setRoomsOpen] = useState(false);
  const [hotelOpen, setHotelOpen] = useState(false);
  const [usersOpen, setUsersOpen] = useState(false);

  return (
    <motion.div
      className="fixed inset-y-0 left-0 w-64 text-gray-100 overflow-y-auto z-30 transform transition-transform ease-in-out"
      style={{
        background: "linear-gradient(to bottom, #1a1a2e, #16213e, #0f3460)",
        boxShadow: "0 4px 20px rgba(0, 0, 0, 0.6)",
        borderRight: "2px solid rgba(255, 255, 255, 0.2)",
      }}
      initial={{ x: isOpen ? -300 : 0 }}
      animate={{ x: isOpen ? 0 : -300 }}
      transition={{ duration: 0.5 }}
    >
      {/* Header */}
      <div className="flex justify-between items-center p-4 border-b border-gray-500">
        <motion.h2
          className="text-3xl font-bold tracking-wide text-white"
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Admin Panel
        </motion.h2>
      </div>

      {/* Navigation Menu */}
      <nav>
        <ul className="space-y-6 mt-6">
          {/* Booking Section */}
          <li>
            <motion.button
              onClick={() => setBookingOpen(!bookingOpen)}
              className="w-full flex justify-between items-center py-3 px-5 text-lg rounded-lg hover:bg-gradient-to-r from-purple-600 to-purple-400 hover:shadow-2xl transform transition-all duration-500"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <CalendarIcon className="w-6 h-6 mr-3 text-purple-300" />
              Booking
              <motion.svg
                className={`w-5 h-5 ml-2 transform ${
                  bookingOpen ? "rotate-180" : ""
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                transition={{ duration: 0.3 }}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M19 9l-7 7-7-7"
                ></path>
              </motion.svg>
            </motion.button>
            {bookingOpen && (
              <motion.ul
                className="ml-8 mt-2 space-y-2"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <li>
                  <Link
                    to="/bookings/all"
                    className="block py-2 px-4 text-base rounded-lg bg-gray-700 hover:bg-purple-600 hover:shadow-lg transition-all"
                  >
                    All Bookings
                  </Link>
                </li>
              </motion.ul>
            )}
          </li>

          {/* Rooms Section */}
          <li>
            <motion.button
              onClick={() => setRoomsOpen(!roomsOpen)}
              className="w-full flex justify-between items-center py-3 px-5 text-lg rounded-lg hover:bg-gradient-to-r from-green-500 to-teal-400 hover:shadow-2xl transform transition-all duration-500"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <DocumentTextIcon className="w-6 h-6 mr-3 text-green-300" />
              Rooms
              <motion.svg
                className={`w-5 h-5 ml-2 transform ${
                  roomsOpen ? "rotate-180" : ""
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                transition={{ duration: 0.3 }}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M19 9l-7 7-7-7"
                ></path>
              </motion.svg>
            </motion.button>
            {roomsOpen && (
              <motion.ul
                className="ml-8 mt-2 space-y-2"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <li>
                  <Link
                    to="/rooms/all"
                    className="block py-2 px-4 text-base rounded-lg bg-gray-700 hover:bg-green-600 hover:shadow-lg transition-all"
                  >
                    All Rooms
                  </Link>
                </li>
              </motion.ul>
            )}
          </li>

          {/* Hotel Section */}
          <li>
            <motion.button
              onClick={() => setHotelOpen(!hotelOpen)}
              className="w-full flex justify-between items-center py-3 px-5 text-lg rounded-lg hover:bg-gradient-to-r from-red-500 to-orange-400 hover:shadow-2xl transform transition-all duration-500"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <OfficeBuildingIcon className="w-6 h-6 mr-3 text-red-300" />
              Hotel
              <motion.svg
                className={`w-5 h-5 ml-2 transform ${
                  hotelOpen ? "rotate-180" : ""
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                transition={{ duration: 0.3 }}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M19 9l-7 7-7-7"
                ></path>
              </motion.svg>
            </motion.button>
            {hotelOpen && (
              <motion.ul
                className="ml-8 mt-2 space-y-2"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <li>
                  <Link
                    to="/hotels/all"
                    className="block py-2 px-4 text-base rounded-lg bg-gray-700 hover:bg-red-600 hover:shadow-lg transition-all"
                  >
                    All Hotels
                  </Link>
                </li>
                <li>
                  <Link
                    to="/hotels/add"
                    className="block py-2 px-4 text-base rounded-lg bg-gray-700 hover:bg-red-600 hover:shadow-lg transition-all"
                  >
                    Add New Hotel
                  </Link>
                </li>
              </motion.ul>
            )}
          </li>

          {/* Users Section */}
          <li>
            <motion.button
              onClick={() => setUsersOpen(!usersOpen)}
              className="w-full flex justify-between items-center py-3 px-5 text-lg rounded-lg hover:bg-gradient-to-r from-yellow-400 to-orange-300 hover:shadow-2xl transform transition-all duration-500"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <UserIcon className="w-6 h-6 mr-3 text-yellow-300" />
              Users
              <motion.svg
                className={`w-5 h-5 ml-2 transform ${
                  usersOpen ? "rotate-180" : ""
                }`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                transition={{ duration: 0.3 }}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M19 9l-7 7-7-7"
                ></path>
              </motion.svg>
            </motion.button>
            {usersOpen && (
              <motion.ul
                className="ml-8 mt-2 space-y-2"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <li>
                  <Link
                    to="/users/all"
                    className="block py-2 px-4 text-base rounded-lg bg-gray-700 hover:bg-yellow-600 hover:shadow-lg transition-all"
                  >
                    All Users
                  </Link>
                </li>
              </motion.ul>
            )}
          </li>
        </ul>
      </nav>
    </motion.div>
  );
};

Sidebar.propTypes = {
  isOpen: PropTypes.bool.isRequired,
};

export default Sidebar;
