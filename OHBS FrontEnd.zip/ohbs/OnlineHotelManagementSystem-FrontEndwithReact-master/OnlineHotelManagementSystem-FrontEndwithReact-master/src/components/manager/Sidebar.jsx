import { useState } from "react";
import { Link } from "react-router-dom";
import { HomeIcon, CalendarIcon, DocumentTextIcon, CogIcon } from "@heroicons/react/outline";
import { motion, AnimatePresence } from "framer-motion";

const Sidebar = () => {
  const [bookingOpen, setBookingOpen] = useState(false);
  const [roomsOpen, setRoomsOpen] = useState(false);

  return (
    <motion.div
      initial={{ x: -300 }}
      animate={{ x: 0 }}
      exit={{ x: -300 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-y-0 left-0 w-64 bg-gradient-to-b from-orange-600 to-purple-700 text-gray-100 shadow-xl z-10 overflow-y-auto"
    >
      <div className="flex justify-between items-center p-7 border-b border-purple-500">
        <h2 className="text-2xl font-bold text-white">Manager Panel</h2>
      </div>
      <nav className="mt-4">
        <ul className="space-y-4">
          {/* Booking Section */}
          <li>
            <button
              onClick={() => setBookingOpen(!bookingOpen)}
              className="w-full flex justify-between items-center py-3 px-5 text-lg font-medium rounded-lg bg-indigo-500 hover:bg-indigo-600 transition-all focus:outline-none shadow-md"
            >
              <CalendarIcon className="w-6 h-6 mr-3" />
              Booking
              <svg
                className={`w-5 h-5 ml-2 transition-transform ${bookingOpen ? "rotate-180" : ""}`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
              </svg>
            </button>
            <AnimatePresence>
              {bookingOpen && (
                <motion.ul
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="ml-8 mt-2"
                >
                  <li>
                    <Link
                      to="/bookings/all"
                      className="block py-2 px-4 text-base rounded-lg hover:bg-purple-600 hover:text-white transition-all"
                    >
                      All Bookings
                    </Link>
                  </li>
                </motion.ul>
              )}
            </AnimatePresence>
          </li>
          {/* Rooms Section */}
          <li>
            <button
              onClick={() => setRoomsOpen(!roomsOpen)}
              className="w-full flex justify-between items-center py-3 px-5 text-lg font-medium rounded-lg bg-indigo-500 hover:bg-indigo-600 transition-all focus:outline-none shadow-md"
            >
              <DocumentTextIcon className="w-6 h-6 mr-3" />
              Rooms
              <svg
                className={`w-5 h-5 ml-2 transition-transform ${roomsOpen ? "rotate-180" : ""}`}
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
              </svg>
            </button>
            <AnimatePresence>
              {roomsOpen && (
                <motion.ul
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="ml-8 mt-2"
                >
                  <li>
                    <Link
                      to="/rooms/all"
                      className="block py-2 px-4 text-base rounded-lg hover:bg-purple-600 hover:text-white transition-all"
                    >
                      All Rooms
                    </Link>
                  </li>
                </motion.ul>
              )}
            </AnimatePresence>
          </li>
        </ul>
      </nav>
    </motion.div>
  );
};

export default Sidebar;
