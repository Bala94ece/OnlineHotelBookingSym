package com.example.ohbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineHotelBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
